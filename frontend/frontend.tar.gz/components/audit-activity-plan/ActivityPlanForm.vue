<template>
  <UModal v-model:open="store.isModalOpen" class="w-full sm:max-w-4xl">
    <div></div>
    <template #content>
    <div class="relative bg-[var(--bg-main)] rounded-xl shadow-2xl flex flex-col max-h-[90vh] border border-[var(--border-main)] transition-colors duration-300">
      <!-- Header -->
      <div class="flex items-center justify-between p-4 border-b border-[var(--border-main)] bg-[var(--bg-surface)] z-10 sticky top-0 rounded-t-xl transition-colors duration-300">
        <h3 class="text-xl font-bold text-[var(--text-main)]">
          {{ store.isEditMode ? 'Edit' : 'Buat' }} Audit Activity Plan
        </h3>
        <UButton
          color="neutral"
          variant="ghost"
          icon="i-heroicons-x-mark-20-solid"
          class="-my-1"
          @click="store.closeModal"
        />
      </div>

      <!-- Content -->
      <div class="flex-1 overflow-y-auto p-4 space-y-6">
        <UForm :state="store.formState" @submit="store.savePlan" class="space-y-6">
          
          <!-- Basic Planning Information -->
          <UCard :ui="{ body: 'px-4 py-5 sm:p-6' }">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-medium">Basic Planning Information</h3>
              </div>
            </template>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <UFormField label="Title of Audit Activity Plan" required>
                <UInput v-model="store.formState.planTitle" placeholder="Audit of the Year 2024" class="w-full"/>
              </UFormField>
              <UFormField label="Planning Year" required>
                <UInput v-model="store.formState.planYear" class="w-full"/>
              </UFormField>
              <UFormField label="Planning Period" required class="col-span-1 md:col-span-2 w-full">
                <div class="flex items-center gap-2">
                  <UInput v-model="store.formState.planPeriodStart" type="date" class="flex-1 w-full" />
                  <span class="text-gray-500">s/d</span>
                  <UInput v-model="store.formState.planPeriodEnd" type="date" class="flex-1 w-full" />
                </div>
              </UFormField>
              <UFormField label="Department/Unit of Audit" required>
                <USelectMenu 
                v-model="store.formState.department" 
                placeholder="Risk Audit IT" 
                class="w-full" 
                :items="Object.values(AuditDepartment)" 
                />
              </UFormField>
              <UFormField label="Created By">
                <UInput v-model="store.formState.createdBy" class="w-full" />
              </UFormField>
            </div>
            <UFormField label="Creation Date" class="pt-4">
              <UInput v-model="store.formState.creationDate" type="date" class="w-full" readonly />
            </UFormField>
          </UCard>

          <!-- Planned Audit Activities -->
          <UCard :ui="{ body: 'px-4 py-5 sm:p-6' }">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-medium">Planned Audit Activities</h3>
                <UButton color="warning" variant="solid" icon="i-heroicons-plus" label="Add Audit Activity" @click="store.addPlannedActivity" />
              </div>
            </template>

            <div class="space-y-6">
              <div v-for="(activity, index) in store.formState.plannedActivities" :key="activity.id" class="border border-[var(--border-main)] rounded-lg p-4 relative bg-[var(--bg-surface)] transition-all duration-300">
                <UButton
                  color="error"
                  variant="ghost"
                  icon="i-heroicons-trash"
                  class="absolute top-2 right-2"
                  @click="store.removePlannedActivity(index)"
                />
                <h4 class="font-medium mb-4">Audit Activity {{ index + 1 }}</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <UFormField label="Title of Audit Activity" required>
                    <UInput v-model="activity.auditName" placeholder="Audit IT Q1" class="w-full"/>
                  </UFormField>
                  <UFormField label="Auditee" required>
                    <UInput v-model="activity.auditee" placeholder="Jamil" class="w-full"/>
                  </UFormField>
                  <UFormField label="Category" class="col-span-1 md:col-span-2">
                    <USelectMenu
                      v-model="activity.category"
                      :items="Object.values(AuditCategory)"
                      placeholder="Select Category"
                      class="w-full"
                    />
                  </UFormField>
                  <UFormField label="Risk Level">
                    <USelectMenu
                      v-model="activity.riskLevel"
                      :items="store.riskLevelOptions"
                      value-key="value"
                      label-key="label"
                      placeholder="Select risk level"
                      class="w-full"
                    />
                  </UFormField>
                  <UFormField label="Duration (days)">
                    <UInput v-model="activity.duration" type="number" class="w-full"/>
                  </UFormField>
                  <UFormField label="Priority">
                    <USelectMenu 
                      v-model="activity.priority" 
                      :items="store.priorityOptions" 
                      value-key="value" 
                      label-key="label" 
                      placeholder="Select priority" 
                      class="w-full"
                    />
                  </UFormField>
                  <UFormField label="Number of Auditors">
                    <UInput v-model="activity.numberOfAuditors" type="number" class="w-full"/>
                  </UFormField>
                  <UFormField label="Estimated Schedule/Time">
                    <UInput v-model="activity.estimatedSchedule" type="date" class="w-full"/>
                  </UFormField>
                  <UFormField label="Budget Estimation">
                    <UInput v-model="activity.budgetEstimation" type="number" class="w-full"/>
                  </UFormField>
                </div>
              </div>
              
              <div v-if="store.formState.plannedActivities.length === 0" class="text-center text-gray-500 py-4">
                No audit activities have been added yet.
              </div>

              <div class="mt-4 border-t pt-4">
                <h4 class="font-medium mb-2">Summary of Activities</h4>
                <div class="grid grid-cols-3 gap-4 text-center">
                  <div class="bg-red-50 text-red-600 rounded-lg p-2  ">
                    <div class="text-xs font-semibold">High Risk</div>
                    <div class="text-lg font-bold">{{ store.formState.plannedActivities.filter(a => String(a.riskLevel) === 'High').length }}</div>
                  </div>
                  <div class="bg-yellow-50 text-yellow-600 rounded-lg p-2  ">
                    <div class="text-xs font-semibold">Medium Risk</div>
                    <div class="text-lg font-bold">{{ store.formState.plannedActivities.filter(a => String(a.riskLevel) === 'Medium').length }}</div>
                  </div>
                  <div class="bg-green-50 text-green-600 rounded-lg p-2  ">
                    <div class="text-xs font-semibold">Low Risk</div>
                    <div class="text-lg font-bold">{{ store.formState.plannedActivities.filter(a => String(a.riskLevel) === 'Low').length }}</div>
                  </div>
                </div>
              </div>
            </div>
          </UCard>

          <!-- Resources & Budget -->
          <UCard :ui="{ body: 'px-4 py-5 sm:p-6' }">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-medium">Resources & Budget</h3>
                <UButton color="warning" variant="solid" icon="i-heroicons-plus" label="Add Auditor" @click="store.addResourceAuditor" />
              </div>
            </template>
            
            <div class="space-y-6">
              <div v-for="(auditor, index) in store.formState.resourceAuditors" :key="auditor.id" class="border border-[var(--border-main)] rounded-lg p-4 relative bg-[var(--bg-surface)] transition-all duration-300">
                 <UButton
                  color="error"
                  variant="ghost"
                  icon="i-heroicons-trash"
                  class="absolute top-2 right-2"
                  @click="store.removeResourceAuditor(index)"
                />
                <h4 class="font-medium mb-4">Auditor {{ index + 1 }}</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <UFormField label="Name">
                    <UInput v-model="auditor.name" placeholder="Jamil" class="w-full"/>
                  </UFormField>
                  <UFormField label="Position">
                    <UInput v-model="auditor.position" placeholder="IT Auditor" class="w-full"/>
                  </UFormField>
                  <UFormField label="Competence">
                    <UInput v-model="auditor.competence" class="w-full"/>
                  </UFormField>
                  <UFormField label="Availability">
                    <UInput v-model="auditor.availability" placeholder="Available" class="w-full"/>
                  </UFormField>
                </div>
              </div>

              <div class="mt-6 border-t pt-4">
                <h4 class="font-medium mb-4">Budget Planning</h4>
                <div class="grid grid-cols-1 gap-4">
                  <UFormField label="Total Estimated Activity Cost">
                    <UInput v-model="store.formState.budget.totalEstimatedCost" type="number" class="w-full"/>
                  </UFormField>
                  <UFormField label="Total Budget Allocated">
                    <UInput v-model="store.formState.budget.totalAllocatedBudget" type="number" class="w-full"/>
                  </UFormField>
                  <UFormField label="Budget Notes">
                    <UTextarea v-model="store.formState.budget.budgetNotes" class="w-full"/>
                  </UFormField>
                </div>
              </div>
            </div>
          </UCard>

          <!-- Review & Approval -->
          <UCard :ui="{ body: 'px-4 py-5 sm:p-6' }">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-medium">Review & Approval</h3>
              </div>
            </template>
            <div class="space-y-6">
              <div>
                <h4 class="font-medium mb-2">Created By</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <UFormField label="Creator Name" required>
                    <UInput v-model="store.formState.review.creatorName" class="w-full"/>
                  </UFormField>
                  <UFormField label="Creator Position" required>
                    <UInput v-model="store.formState.review.creatorPosition" class="w-full"/>
                  </UFormField>
                </div>
              </div>
              <div class="border-t pt-4">
                <h4 class="font-medium mb-2">Approved By</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <UFormField label="Approver Name" required>
                    <UInput v-model="store.formState.review.approverName" class="w-full"/>
                  </UFormField>
                  <UFormField label="Approver Position" required>
                    <UInput v-model="store.formState.review.approverPosition" class="w-full"/>
                  </UFormField>
                </div>
                <UFormField label="Approval Date" class="pt-4" required>
                  <UInput v-model="store.formState.review.approvalDate" type="date" class="w-full"/>
                </UFormField>
                <UFormField label="Additional Notes" class="col-span-1 md:col-span-2 pt-4">
                  <UTextarea v-model="store.formState.review.additionalNotes" class="w-full"/>
                </UFormField>
                
              </div>
            </div>
          </UCard>

          <!-- Buttons -->
          <div class="flex justify-end gap-3 pb-6">
            <UButton label="Cancel" color="neutral" variant="ghost" @click="store.closeModal" />
            <UButton type="submit" :label="store.isEditMode ? 'Update' : 'Create'" color="warning" />
          </div>

        </UForm>
      </div>
    </div>
    </template>
  </UModal>
</template>

<script setup lang="ts">
import { useActivityPlanStore } from '~/stores/activity-plan'
import { AuditCategory, AuditDepartment } from '~/types/audit';

const store = useActivityPlanStore()
</script>
